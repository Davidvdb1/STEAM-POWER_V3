window.env = {
    BACKEND_URL: 'http://localhost:3000'
};
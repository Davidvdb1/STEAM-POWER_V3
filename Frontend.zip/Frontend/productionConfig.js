window.env = {
    BACKEND_URL: 'https://twabackend.davidvandenbroeck.com'
};